#!/bin/sh/

docker build -t trt_starter:cuda11.4-cudnn8-tensorrt8.2_${1} .
