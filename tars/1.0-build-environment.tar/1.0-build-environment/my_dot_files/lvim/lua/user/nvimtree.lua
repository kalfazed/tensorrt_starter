
lvim.builtin.nvimtree.setup.view.side = "left"
lvim.builtin.nvimtree.setup.renderer.icons.show.git = false

lvim.builtin.nvimtree.setup.view.centralize_selection = true

-- lvim.builtin.nvimtree.setup.actions.open_file.quit_on_open = true
